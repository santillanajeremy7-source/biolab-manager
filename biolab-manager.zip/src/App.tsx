/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Beaker, Layers, HelpCircle, ShieldCheck, HeartPulse, RefreshCw } from 'lucide-react';
import { LabPractice } from './types';
import SystemInfoSection from './components/SystemInfoSection';
import PracticeForm from './components/PracticeForm';
import PracticeList from './components/PracticeList';

const INITIAL_PRACTICES: LabPractice[] = [
  {
    id: '1',
    practiceName: 'Extracción de ADN de Plátano de Seda',
    studentName: 'Sofía Delgado Reyes',
    date: '2026-06-01',
    observations: 'Se homogenizó la pulpa del plátano en solución salina con detergente para lisar las membranas lipídicas celulares. Tras filtrar las fibras insolubles, se adicionó etanol al 96% frío por la pared del tubo de ensayo. Se observó una precipitación blanquecina filamentosa en la interfase agua-alcohol.',
    category: 'Genética',
    groupName: 'Grupo A',
    safetyEquipmentChecked: true,
  },
  {
    id: '2',
    practiceName: 'Acción de la Amilasa Salival sobre el Almidón',
    studentName: 'Mateo Gómez Silva',
    date: '2026-06-01',
    observations: 'Se prepararon tres tubos con suspensión de almidón. El tubo 1 (incubado con saliva a 37°C) no mostró tinción azul con reactivo de Lugol, indicando digestión completa. Los tubos 2 (con saliva hervida experimentalmente) y 3 (pH ácido con HCl) dieron positivo azul, indicando desnaturalización enzimática.',
    category: 'Fisiología',
    groupName: 'Grupo B',
    safetyEquipmentChecked: true,
  },
  {
    id: '3',
    practiceName: 'Observación de Estomas en la Epidermis de Tradescantia',
    studentName: 'Valentina Torres Prado',
    date: '2026-06-02',
    observations: 'Se obtuvo una fina capa de la epidermis abaxial de la hoja. Al microscopio óptico con aumento de 400x se distinguieron con total claridad las células oclusivas bilobuladas, las células anexas circundantes y el ostíolo central regulador del intercambio gaseoso.',
    category: 'Botánica',
    groupName: 'Grupo A',
    safetyEquipmentChecked: true,
  },
  {
    id: '4',
    practiceName: 'Fermentación Anaeróbica de Levaduras',
    studentName: 'Alejandro Ruiz Díaz',
    date: '2026-06-03',
    observations: 'Se incubó levadura comercial (Saccharomyces cerevisiae) en agua tibia con sacarosa en una botella conectada a un globo. A los 10 minutos se observó burbujeo constante e inflación total del globo por la acumulación del dióxido de carbono metabólico.',
    category: 'Microbiología',
    groupName: 'Grupo C',
    safetyEquipmentChecked: false,
  }
];

export default function App() {
  const [practices, setPractices] = useState<LabPractice[]>([]);

  // Load from local storage or defaults on mount
  useEffect(() => {
    const stored = localStorage.getItem('biolab_manager_practices');
    if (stored) {
      try {
        setPractices(JSON.parse(stored));
      } catch (e) {
        console.error('Error parsing localStorage biolab_manager_practices:', e);
        setPractices(INITIAL_PRACTICES);
      }
    } else {
      setPractices(INITIAL_PRACTICES);
      localStorage.setItem('biolab_manager_practices', JSON.stringify(INITIAL_PRACTICES));
    }
  }, []);

  // Update localStorage when practices change
  const savePractices = (updated: LabPractice[]) => {
    setPractices(updated);
    localStorage.setItem('biolab_manager_practices', JSON.stringify(updated));
  };

  const handleAddPractice = (newPracticeData: Omit<LabPractice, 'id'>) => {
    const newPractice: LabPractice = {
      ...newPracticeData,
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9),
    };
    savePractices([newPractice, ...practices]);
  };

  const handleDeletePractice = (id: string) => {
    const filtered = practices.filter((practice) => practice.id !== id);
    savePractices(filtered);
  };

  const handleRestoreDefaults = () => {
    if (window.confirm('¿Está seguro de que desea restaurar las prácticas predefinidas del laboratorio de biología? Se perderán las modificaciones actuales.')) {
      savePractices(INITIAL_PRACTICES);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex flex-col antialiased font-sans relative overflow-x-hidden">
      
      {/* Ambient Bioluminescent Glowing Spots */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-[-5%] left-[-5%] w-[45%] h-[45%] bg-emerald-650/15 rounded-full blur-[110px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-cyan-650/15 rounded-full blur-[130px]"></div>
        <div className="absolute top-[35%] right-[15%] w-[35%] h-[35%] bg-teal-600/10 rounded-full blur-[100px]"></div>
      </div>

      {/* Main Container Header with Glassmorphism */}
      <header className="relative z-10 bg-white/5 backdrop-blur-xl border-b border-white/10 py-5 px-6 shadow-lg">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-400 to-cyan-500 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/20">
              <Beaker size={20} className="stroke-[2.5px]" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-emerald-300 to-cyan-300">
                BioLab Manager
              </h1>
              <p className="text-xs text-slate-400">
                Bitácora Digital de Prácticas y Bioseguridad — Academia de Biología
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block mr-2">
              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Periodo Académico</p>
              <p className="text-xs text-emerald-400 font-medium font-mono">Semestre Científico 22-A</p>
            </div>
            <div className="h-8 w-px bg-white/10 hidden sm:block" />
            <button
              onClick={handleRestoreDefaults}
              className="px-3.5 py-1.5 text-xs font-semibold bg-white/5 text-slate-200 hover:text-white hover:bg-white/10 rounded-xl border border-white/10 transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
              title="Restablecer plantilla inicial de biología"
            >
              <RefreshCw size={13} className="text-emerald-400" />
              Reestablecer
            </button>
          </div>
        </div>
      </header>

      {/* Core Body Container */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        
        {/* System Info Section Segment */}
        <SystemInfoSection practices={practices} />

        {/* Responsive Bento Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          
          {/* Form Column */}
          <div className="lg:col-span-1">
            <PracticeForm onAddPractice={handleAddPractice} />
          </div>

          {/* List Column */}
          <div className="lg:col-span-2">
            <PracticeList 
              practices={practices} 
              onDeletePractice={handleDeletePractice} 
              onRestoreDefaults={() => savePractices(INITIAL_PRACTICES)}
            />
          </div>

        </div>

      </main>

      {/* Footer Branding with Glassmorphism */}
      <footer className="relative z-10 bg-white/3 border-t border-white/10 py-5 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>&copy; 2026 <strong className="text-slate-350">BioLab Systems</strong> | V2.4.0-Stable</span>
          </div>
          <div className="flex items-center gap-3 font-mono text-[10px] text-slate-400">
            <span>Estación: LocalStorage Activo</span>
            <span className="text-emerald-500/60 font-bold">•</span>
            <span>System Health: Optimal</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
