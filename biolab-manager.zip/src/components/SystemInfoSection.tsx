import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Beaker, ShieldCheck, FileSpreadsheet, Users, Info, Sparkles, HelpCircle } from 'lucide-react';
import { LabPractice } from '../types';

interface SystemInfoSectionProps {
  practices: LabPractice[];
}

export default function SystemInfoSection({ practices }: SystemInfoSectionProps) {
  const [showSafetyTips, setShowSafetyTips] = useState(true);

  // Stats calculations
  const totalPractices = practices.length;
  const uniqueStudents = new Set(practices.map(p => p.studentName.trim().toLowerCase())).size;
  const safetyCheckedCount = practices.filter(p => p.safetyEquipmentChecked).length;
  const safetyPercentage = totalPractices > 0 ? Math.round((safetyCheckedCount / totalPractices) * 100) : 100;

  const safetyRules = [
    { id: 'rule1', text: 'Uso obligatorio de bata blanca de algodón de manga larga.' },
    { id: 'rule2', text: 'Gafas de seguridad y guantes de nitrilo para manipulación de reactivos.' },
    { id: 'rule3', text: 'Cabello recogido, calzado cerrado y sin accesorios colgantes hacia las muestras.' },
    { id: 'rule4', text: 'Prohibido consumir alimentos, bebidas o fumar dentro del laboratorio.' },
    { id: 'rule5', text: 'Identificar rutas de evacuación, extintores y la estación de lavaojos.' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      {/* Welcome & Info Card (Translucent Deep Bio-Glass) */}
      <motion.div 
        id="sys-info-welcome-card"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between lg:col-span-2"
      >
        <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
          <Beaker size={180} className="text-emerald-400 rotate-12" />
        </div>

        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-xs text-emerald-350 font-medium mb-4">
            <Sparkles size={12} className="animate-pulse" />
            <span>Sistema Activo — Laboratorio Digital Sincronizado</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-sans font-bold tracking-tight text-white mb-2">
            BioLab Manager
          </h2>
          <p className="text-xs md:text-sm text-slate-300 max-w-xl leading-relaxed mb-6">
            Plataforma centralizada para el registro científico y pedagógico de prácticas de laboratorio. Optimiza el seguimiento de observaciones, fomenta la precisión de los reportes y asegura el control del protocolo biológico de seguridad.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3 md:gap-4 mt-2">
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10 text-center hover:bg-white/10 transition-colors">
            <div className="text-emerald-400 flex justify-center mb-1">
              <FileSpreadsheet size={18} />
            </div>
            <div className="text-lg md:text-xl font-bold font-mono text-white leading-none">
              {totalPractices}
            </div>
            <div className="text-[10px] text-slate-300 mt-1.5 uppercase tracking-wider font-semibold">
              Prácticas
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10 text-center hover:bg-white/10 transition-colors">
            <div className="text-cyan-400 flex justify-center mb-1">
              <Users size={18} />
            </div>
            <div className="text-lg md:text-xl font-bold font-mono text-white leading-none">
              {uniqueStudents}
            </div>
            <div className="text-[10px] text-slate-300 mt-1.5 uppercase tracking-wider font-semibold">
              Estudiantes
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-3 border border-white/10 text-center hover:bg-white/10 transition-colors">
            <div className="text-teal-350 flex justify-center mb-1">
              <ShieldCheck size={18} />
            </div>
            <div className="text-lg md:text-xl font-bold font-mono text-white leading-none">
              {safetyPercentage}%
            </div>
            <div className="text-[10px] text-slate-300 mt-1.5 uppercase tracking-wider font-semibold">
              EPI Seguro
            </div>
          </div>
        </div>
      </motion.div>

      {/* Safety & Quick Tips Card (Perfect Transparent Glass Pane) */}
      <motion.div 
        id="sys-info-safety-card"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.15 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-md flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-white/5 text-emerald-400 rounded-lg border border-white/10">
                <ShieldCheck size={20} />
              </div>
              <h3 className="font-sans font-bold text-slate-200 text-sm">
                Protocolo de Bioseguridad
              </h3>
            </div>
            <button 
              onClick={() => setShowSafetyTips(!showSafetyTips)}
              className="text-slate-400 hover:text-emerald-400 transition-colors p-1"
              title="Información"
            >
              <Info size={16} />
            </button>
          </div>

          {showSafetyTips ? (
            <div className="space-y-3">
              <p className="text-xs text-slate-400 mb-2 leading-relaxed">
                Antes de iniciar el registro científico, verifique que los estudiantes estén cumpliendo con las normas elementales de bioseguridad escolar:
              </p>
              <div className="space-y-2 max-h-[170px] overflow-y-auto pr-1 text-slate-300">
                {safetyRules.map((rule) => (
                  <div key={rule.id} className="flex items-start gap-2.5 text-xs">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full mt-1.5 shrink-0" />
                    <span>{rule.text}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-3 py-2 text-center text-xs text-slate-400">
              <p className="font-semibold text-emerald-300">Funcionamiento LocalStorage</p>
              <p className="leading-relaxed">
                Los datos registrados de cada práctica se guardan de forma persistente en su navegador local mediante <code className="bg-white/10 text-cyan-300 rounded px-1 py-0.5 font-mono">localStorage</code>.
              </p>
              <p className="leading-relaxed">
                Puede cerrar la pestaña o recargar la página, y sus registros permanecerán disponibles de forma indefinida en este dispositivo.
              </p>
            </div>
          )}
        </div>

        <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-500">
          <span className="font-mono">BioLab v2.4.0</span>
          <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
            <Beaker size={12} />
            Control de Muestras
          </span>
        </div>
      </motion.div>
    </div>
  );
}
