import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Beaker, User, Calendar, FileText, PlusCircle, ShieldAlert, BadgeHelp, Check } from 'lucide-react';
import { LabPractice } from '../types';

interface PracticeFormProps {
  onAddPractice: (practice: Omit<LabPractice, 'id'>) => void;
}

export default function PracticeForm({ onAddPractice }: PracticeFormProps) {
  const [practiceName, setPracticeName] = useState('');
  const [studentName, setStudentName] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [observations, setObservations] = useState('');
  const [category, setCategory] = useState<LabPractice['category']>('Microbiología');
  const [safetyEquipmentChecked, setSafetyEquipmentChecked] = useState(true);
  const [groupName, setGroupName] = useState('Grupo A');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [successMsg, setSuccessMsg] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    const nextErrors: Record<string, string> = {};
    if (!practiceName.trim()) {
      nextErrors.practiceName = 'El nombre de la práctica es obligatorio.';
    }
    if (!studentName.trim()) {
      nextErrors.studentName = 'El nombre del estudiante es obligatorio.';
    }
    if (!date) {
      nextErrors.date = 'La fecha de la práctica es requerida.';
    }
    if (!observations.trim()) {
      nextErrors.observations = 'Las observaciones de la práctica son requeridas.';
    }

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    // Reset error state
    setErrors({});

    // Submit practice parameters
    onAddPractice({
      practiceName: practiceName.trim(),
      studentName: studentName.trim(),
      date,
      observations: observations.trim(),
      category,
      groupName,
      safetyEquipmentChecked,
    });

    // Clear form fields
    setPracticeName('');
    setStudentName('');
    setObservations('');
    // Retain safetyEquipmentChecked, date, and category for subsequent entries as convenient defaults

    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 3000);
  };

  return (
    <motion.div
      id="register-practice-form-container"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl text-slate-150"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-white/5 text-emerald-405 rounded-xl border border-white/10 shadow-inner">
          <Beaker size={22} className="animate-pulse text-emerald-400" />
        </div>
        <div>
          <h3 className="font-sans font-bold text-white text-lg">
            Registrar Práctica
          </h3>
          <p className="text-xs text-slate-450 text-slate-400 mt-0.5">
            Diligencie los datos técnicos del experimento
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        
        {/* Practice Name Field */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 ml-1">
            Nombre de la Práctica *
          </label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
              <Beaker size={16} />
            </span>
            <input
              type="text"
              className={`w-full bg-white/5 border text-sm text-white pl-10 pr-4 py-2.5 rounded-xl transition-all placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:bg-white/10 ${
                errors.practiceName 
                  ? 'border-red-500/50 focus:ring-red-500/30' 
                  : 'border-white/10 focus:ring-emerald-500/50 focus:border-emerald-400'
              }`}
              placeholder="e.g. Observación de Mitosis en Cebolla"
              value={practiceName}
              onChange={(e) => {
                setPracticeName(e.target.value);
                if (errors.practiceName) setErrors({ ...errors, practiceName: '' });
              }}
            />
          </div>
          {errors.practiceName && (
            <p className="text-xs text-red-450 mt-1.5 flex items-center gap-1 text-red-400">
              <ShieldAlert size={12} /> {errors.practiceName}
            </p>
          )}
        </div>

        {/* Student Name & Date Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 ml-1">
              Estudiante *
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                <User size={16} />
              </span>
              <input
                type="text"
                className={`w-full bg-white/5 border text-sm text-white pl-10 pr-4 py-2.5 rounded-xl transition-all placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:bg-white/10 ${
                  errors.studentName 
                    ? 'border-red-500/50 focus:ring-red-500/30' 
                    : 'border-white/10 focus:ring-emerald-500/50 focus:border-emerald-400'
                }`}
                placeholder="e.g. María Alejandra Pérez"
                value={studentName}
                onChange={(e) => {
                  setStudentName(e.target.value);
                  if (errors.studentName) setErrors({ ...errors, studentName: '' });
                }}
              />
            </div>
            {errors.studentName && (
              <p className="text-xs text-red-450 mt-1.5 flex items-center gap-1 text-red-400">
                <ShieldAlert size={12} /> {errors.studentName}
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 ml-1">
              Fecha *
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                <Calendar size={16} />
              </span>
              <input
                type="date"
                style={{ contentVisibility: 'auto' }}
                className={`w-full bg-white/5 border text-sm text-white pl-10 pr-4 py-2.5 rounded-xl transition-all focus:outline-none focus:ring-2 focus:bg-white/10 [color-scheme:dark] ${
                  errors.date 
                    ? 'border-red-500/50 focus:ring-red-500/30' 
                    : 'border-white/10 focus:ring-emerald-500/50 focus:border-emerald-400'
                }`}
                value={date}
                onChange={(e) => {
                  setDate(e.target.value);
                  if (errors.date) setErrors({ ...errors, date: '' });
                }}
              />
            </div>
            {errors.date && (
              <p className="text-xs text-red-450 mt-1.5 flex items-center gap-1 text-red-400">
                <ShieldAlert size={12} /> {errors.date}
              </p>
            )}
          </div>
        </div>

        {/* Biology Category & Lab Group */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 ml-1">
              Rama Biológica
            </label>
            <select
              className="w-full bg-slate-900/40 backdrop-blur-md border border-white/10 text-sm text-slate-200 px-4 py-2.5 rounded-xl transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-450"
              value={category}
              onChange={(e) => setCategory(e.target.value as LabPractice['category'])}
            >
              <option value="Microbiología" className="bg-slate-950 text-white">🧫 Microbiología</option>
              <option value="Genética" className="bg-slate-950 text-white">🧬 Genética</option>
              <option value="Botánica" className="bg-slate-950 text-white">🌱 Botánica</option>
              <option value="Fisiología" className="bg-slate-950 text-white">🫁 Fisiología</option>
              <option value="Ecología" className="bg-slate-950 text-white">🌎 Ecología</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 ml-1">
              Grupo de Trabajo
            </label>
            <select
              className="w-full bg-slate-900/40 backdrop-blur-md border border-white/10 text-sm text-slate-200 px-4 py-2.5 rounded-xl transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-450"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
            >
              <option value="Grupo A" className="bg-slate-950 text-white">Grupo A</option>
              <option value="Grupo B" className="bg-slate-950 text-white">Grupo B</option>
              <option value="Grupo C" className="bg-slate-950 text-white">Grupo C</option>
              <option value="Investigación" className="bg-slate-950 text-white">Equipo Especial</option>
            </select>
          </div>
        </div>

        {/* Observations Field */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 ml-1">
            Observaciones Científicas o Resultados *
          </label>
          <div className="relative">
            <span className="absolute top-3 left-3 text-slate-400">
              <FileText size={16} />
            </span>
            <textarea
              rows={3}
              className={`w-full bg-white/5 border text-sm text-white pl-10 pr-4 py-2.5 rounded-xl transition-all placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:bg-white/10 resize-none ${
                errors.observations 
                  ? 'border-red-500/50 focus:ring-red-500/30' 
                  : 'border-white/10 focus:ring-emerald-500/50 focus:border-emerald-400'
              }`}
              placeholder="e.g. Tras agregar reactivo de Lugol, se evidenció cambio de coloración azul-violeta..."
              value={observations}
              onChange={(e) => {
                setObservations(e.target.value);
                if (errors.observations) setErrors({ ...errors, observations: '' });
              }}
            />
          </div>
          {errors.observations && (
            <p className="text-xs text-red-450 mt-1.5 flex items-center gap-1 text-red-400">
              <ShieldAlert size={12} /> {errors.observations}
            </p>
          )}
        </div>

        {/* Safety Equip Switch */}
        <div className="flex items-center justify-between p-3.5 bg-white/5 border border-white/10 rounded-xl">
          <div className="flex flex-col pr-2">
            <span className="text-xs font-bold text-emerald-350 flex items-center gap-1.5">
              <span>🛡️ Bioseguridad EPI</span>
            </span>
            <span className="text-[11px] text-slate-400 mt-0.5">Bata, guantes y protección obligatorios.</span>
          </div>
          <button
            type="button"
            onClick={() => setSafetyEquipmentChecked(!safetyEquipmentChecked)}
            className={`w-12 h-6.5 rounded-full p-0.5 transition-colors focus:outline-none cursor-pointer shrink-0 ${
              safetyEquipmentChecked ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-5.5 h-5.5 rounded-full bg-white shadow-md transition-transform transform ${
                safetyEquipmentChecked ? 'translate-x-[22px]' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Action Button & Feedback */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-emerald-555 from-emerald-550 via-teal-500 to-cyan-550 text-slate-950 hover:from-emerald-400 hover:to-cyan-400 py-3.5 px-4 rounded-xl font-sans font-bold text-sm tracking-wide transition-all shadow-lg shadow-emerald-500/10 focus:outline-none focus:ring-2 focus:ring-emerald-405 active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
          >
            <PlusCircle size={18} />
            Registrar en Bitácora
          </button>
        </div>

        <AnimatePresence>
          {successMsg && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="p-3 bg-emerald-500/20 text-emerald-300 rounded-xl text-xs text-center font-medium font-sans flex items-center justify-center gap-1.5 border border-emerald-500/30"
            >
              <Check size={14} className="stroke-[3px]" />
              ¡Sincronizado correctamente en LocalStorage!
            </motion.div>
          )}
        </AnimatePresence>
      </form>
    </motion.div>
  );
}
