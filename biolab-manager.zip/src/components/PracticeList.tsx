import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Trash2, Calendar, User, Eye, EyeOff, ClipboardList, RefreshCw, Layers, ShieldCheck, ShieldAlert } from 'lucide-react';
import { LabPractice } from '../types';

interface PracticeListProps {
  practices: LabPractice[];
  onDeletePractice: (id: string) => void;
  onRestoreDefaults: () => void;
}

export default function PracticeList({ practices, onDeletePractice, onRestoreDefaults }: PracticeListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedPracticeId, setExpandedPracticeId] = useState<string | null>(null);

  // Filters logic
  const filteredPractices = practices.filter((practice) => {
    const matchesSearch = 
      practice.practiceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      practice.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      practice.observations.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || practice.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const getCategoryBadge = (category: LabPractice['category']) => {
    switch (category) {
      case 'Microbiología':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-fuchsia-550 bg-fuchsia-500/10 text-fuchsia-300 border border-fuchsia-500/20">
            🧫 Microbiología
          </span>
        );
      case 'Genética':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
            🧬 Genética
          </span>
        );
      case 'Botánica':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
            🌱 Botánica
          </span>
        );
      case 'Fisiología':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-300 border border-rose-500/20">
            𫫇 Fisiología
          </span>
        );
      case 'Ecología':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
            🌎 Ecología
          </span>
        );
      default:
        return null;
    }
  };

  const toggleExpand = (id: string) => {
    if (expandedPracticeId === id) {
      setExpandedPracticeId(null);
    } else {
      setExpandedPracticeId(id);
    }
  };

  return (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl text-slate-100">
      {/* Header & Search Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h3 className="font-sans font-bold text-white text-lg flex items-center gap-2">
            <ClipboardList size={20} className="text-emerald-400" />
            Cuaderno de Registros Biológicos
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Visualización histórica, búsqueda y control de prácticas escolares guardadas
          </p>
        </div>

        {/* Restore defaults if blank */}
        {practices.length === 0 && (
          <button
            onClick={onRestoreDefaults}
            className="self-start md:self-auto inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-white/5 text-emerald-300 rounded-xl hover:bg-white/10 transition-colors border border-white/10 cursor-pointer"
          >
            <RefreshCw size={13} className="animate-spin-slow" />
            Cargar Plantillas de Demostración
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <div className="relative md:col-span-2">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            className="w-full bg-white/5 border border-white/10 text-sm text-white pl-10 pr-4 py-2 rounded-xl transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:bg-white/10"
            placeholder="Buscar por práctica, estudiante u observaciones..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div>
          <select
            className="w-full bg-slate-900/40 backdrop-blur-md border border-white/10 text-sm text-slate-200 px-3 py-2 rounded-xl transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="all" className="bg-slate-950 text-white">📁 Mostrar Todo (Categorías)</option>
            <option value="Microbiología" className="bg-slate-950 text-white">🧫 Microbiología</option>
            <option value="Genética" className="bg-slate-950 text-white">🧬 Genética</option>
            <option value="Botánica" className="bg-slate-950 text-white">🌱 Botánica</option>
            <option value="Fisiología" className="bg-slate-950 text-white">🫁 Fisiología</option>
            <option value="Ecología" className="bg-slate-950 text-white">🌎 Ecología</option>
          </select>
        </div>
      </div>

      {/* Results Count Info */}
      <div className="flex items-center justify-between text-xs text-slate-400 mb-3 px-1">
        <span>Mostrando {filteredPractices.length} de {practices.length} prácticas registradas</span>
        {searchTerm || selectedCategory !== 'all' ? (
          <button 
            onClick={() => { setSearchTerm(''); setSelectedCategory('all'); }} 
            className="text-emerald-400 hover:underline font-medium cursor-pointer"
          >
            Limpiar Filtros
          </button>
        ) : null}
      </div>

      {/* Practices Interactive Table / Cards View */}
      {filteredPractices.length === 0 ? (
        <div className="text-center py-12 px-4 border border-dashed border-white/10 rounded-2xl bg-white/3 flex flex-col items-center justify-center">
          <ClipboardList size={40} className="text-slate-500 mb-3" />
          <h4 className="font-sans font-bold text-slate-200 text-sm mb-1">
            Ningún registro coincide con la búsqueda
          </h4>
          <p className="text-xs text-slate-400 max-w-sm mb-4">
            Asegúrese de escribir palabras clave válidas o seleccione otra rama biológica en el filtro superior.
          </p>
          {practices.length === 0 && (
            <button
              onClick={onRestoreDefaults}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 rounded-xl text-xs font-semibold hover:from-emerald-400 hover:to-cyan-400 shadow-sm transition-all cursor-pointer"
            >
              Cargar Muestras Biológicas de Demostración
            </button>
          )}
        </div>
      ) : (
        <>
          {/* Desktop Version: Perfect Responsive Table */}
          <div className="hidden lg:block overflow-x-auto border border-white/10 rounded-xl">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-white/5 border-b border-white/10 text-[11px] uppercase tracking-wider text-slate-400 font-bold">
                  <th className="py-3.5 px-4">Práctica / Estudiante</th>
                  <th className="py-3.5 px-4">Categoría</th>
                  <th className="py-3.5 px-4">Fecha</th>
                  <th className="py-3.5 px-4">Bioseguridad</th>
                  <th className="py-3.5 px-4">Observaciones Científicas</th>
                  <th className="py-3.5 px-4 text-center">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-sm text-slate-350">
                <AnimatePresence initial={false}>
                  {filteredPractices.map((practice) => (
                    <motion.tr
                      key={practice.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.2 }}
                      className="hover:bg-white/3 transition-colors"
                    >
                      <td className="py-3.5 px-4 max-w-[220px]">
                        <div className="font-semibold text-white trim-text block truncate" title={practice.practiceName}>
                          {practice.practiceName}
                        </div>
                        <div className="text-xs text-slate-405 text-slate-405 text-slate-400 flex items-center gap-1 mt-0.5">
                          <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400/50"></span>
                          <span>{practice.studentName}</span>
                          {practice.groupName && (
                            <span className="text-[10px] bg-white/10 text-emerald-300 px-1 py-0.2 rounded font-mono">
                              {practice.groupName}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {getCategoryBadge(practice.category)}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap text-xs text-slate-450 text-slate-400 font-mono">
                        {practice.date}
                      </td>
                      <td className="py-3.5 px-4">
                        {practice.safetyEquipmentChecked ? (
                          <div className="inline-flex items-center gap-1 text-[11px] text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                            <ShieldCheck size={12} className="stroke-[2.5px]" />
                            Correcto
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1 text-[11px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                            <ShieldAlert size={12} />
                            Faltante
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 max-w-[280px]">
                        <p className="text-xs text-slate-350 text-slate-300 line-clamp-2 leading-relaxed" title={practice.observations}>
                          {practice.observations}
                        </p>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => toggleExpand(practice.id)}
                            className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                            title={expandedPracticeId === practice.id ? "Contraer" : "Expandir observaciones"}
                          >
                            {expandedPracticeId === practice.id ? <EyeOff size={15} /> : <Eye size={15} />}
                          </button>
                          <button
                            onClick={() => onDeletePractice(practice.id)}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                            title="Eliminar Registro"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>

          {/* Expanded observations panel for desktop */}
          <AnimatePresence>
            {expandedPracticeId && filteredPractices.some(p => p.id === expandedPracticeId) && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="hidden lg:block mt-3 p-4 bg-emerald-500/5 rounded-xl border border-emerald-500/20"
              >
                {(() => {
                  const p = filteredPractices.find(p => p.id === expandedPracticeId)!;
                  return (
                    <div className="text-xs">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-bold text-emerald-350 tracking-wider uppercase text-[10px]">Detalle Completo del Experimento</span>
                        <button onClick={() => setExpandedPracticeId(null)} className="text-slate-400 hover:text-white p-1">×</button>
                      </div>
                      <p className="font-semibold text-white text-sm mb-1">{p.practiceName}</p>
                      <div className="grid grid-cols-3 gap-2 text-slate-400 mb-2 font-mono text-[10px]">
                        <div>Estudiante: {p.studentName}</div>
                        <div>Fecha: {p.date}</div>
                        <div>Categoría: {p.category}</div>
                      </div>
                      <div className="text-slate-200 bg-slate-950/40 p-3 rounded-lg border border-white/5 leading-relaxed font-sans text-sm whitespace-pre-wrap">
                        {p.observations}
                      </div>
                    </div>
                  );
                })()}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Mobile Version: Highly Adaptive & Touch-Friendly Scrolling List */}
          <div className="lg:hidden space-y-4">
            <AnimatePresence initial={false}>
              {filteredPractices.map((practice) => (
                <motion.div
                  key={practice.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="bg-white/3 rounded-xl p-4 border border-white/10 hover:border-emerald-500/30 transition-all flex flex-col gap-3 relative"
                >
                  {/* Card Title & Category */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex flex-col gap-1">
                      <div className="text-sm font-bold text-white leading-snug">
                        {practice.practiceName}
                      </div>
                      <div className="flex flex-wrap gap-1.5 items-center mt-0.5">
                        {getCategoryBadge(practice.category)}
                        {practice.groupName && (
                          <span className="text-[10px] bg-white/10 text-emerald-300 px-1.5 py-0.2 rounded font-mono">
                            {practice.groupName}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => onDeletePractice(practice.id)}
                      className="p-2 text-slate-400 hover:text-red-400 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors cursor-pointer shrink-0"
                      title="Eliminar Registro"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>

                  {/* Date, Student Info & Bioseguridad Check */}
                  <div className="grid grid-cols-2 gap-2 py-2 border-y border-white/10 text-xs text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <User size={13} className="text-slate-400 shrink-0" />
                      <span className="truncate">{practice.studentName}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Calendar size={13} className="text-slate-400 shrink-0" />
                      <span className="font-mono">{practice.date}</span>
                    </div>
                    <div className="col-span-2 flex items-center gap-1.5 pt-1">
                      <span className="text-slate-450 text-slate-500 text-[10px] uppercase font-bold tracking-tight">Seguridad:</span>
                      {practice.safetyEquipmentChecked ? (
                        <span className="inline-flex items-center gap-1 text-[11px] text-emerald-300 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/15">
                          EPI Correcto
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] text-amber-300 font-semibold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/15">
                          Falta de EPI
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Observations Section */}
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                      Observaciones Científicas
                    </span>
                    <p className="text-xs text-slate-350 text-slate-300 leading-relaxed bg-slate-950/40 p-2.5 rounded-lg border border-white/5">
                      {practice.observations}
                    </p>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </>
      )}
    </div>
  );
}
