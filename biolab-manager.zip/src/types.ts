/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LabPractice {
  id: string;
  practiceName: string;
  studentName: string;
  date: string;
  observations: string;
  category: 'Microbiología' | 'Genética' | 'Botánica' | 'Fisiología' | 'Ecología';
  groupName?: string; // Optional: e.g. "Grupo A", "Grupo B"
  safetyEquipmentChecked: boolean; // Nice bio touch: security equipment check
}

export interface SystemInfo {
  version: string;
  updatedAt: string;
  totalPractices: number;
  activeStudents: number;
  academicTerm: string;
}
